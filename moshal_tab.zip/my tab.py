from http.server import SimpleHTTPRequestHandler
import socketserver

PORT = 8000

with socketserver.TCPServer(("", PORT), SimpleHTTPRequestHandler) as httpd:
    print("Server running at http://localhost:8000")
    httpd.serve_forever()