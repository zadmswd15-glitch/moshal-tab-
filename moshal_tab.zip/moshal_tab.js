const suggestionsData = [
    'moshal tab history',
    'olive gold design',
    'mobile browser UI',
    'latest news',
    'weather forecast',
    'how to customize'
];

function search() {
    const query = document.getElementById('searchInput').value.trim();
    if (!query) return;

    const isUrl = query.match(/^https?:\/\//i);
    if (isUrl) {
        window.location.href = query;
    } else {
        window.location.href = 'https://www.bing.com/search?q=' + encodeURIComponent(query);
    }
}

function showSuggestions(text) {
    const ul = document.getElementById('suggestions');
    ul.innerHTML = '';
    if (!text.trim()) {
        ul.classList.remove('active');
        return;
    }

    const matches = suggestionsData.filter(s => s.toLowerCase().includes(text.toLowerCase()));
    if (!matches.length) {
        ul.classList.remove('active');
        return;
    }

    matches.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item;
        li.onclick = () => {
            document.getElementById('searchInput').value = item;
            search();
        };
        ul.appendChild(li);
    });

    ul.classList.add('active');
}

document.getElementById('searchInput').addEventListener('input', (e) => {
    showSuggestions(e.target.value);
});

document.getElementById('searchInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        search();
    }
});

function openCard(url) {
    window.open(url, '_blank');
}

function goBack() { window.history.back(); }
function goForward() { window.history.forward(); }
function goHome() { window.location.href = window.location.origin + window.location.pathname; }
function openRecent() { alert('Recent tabs feature is not available yet!'); }

// Shortcut links
Array.from(document.querySelectorAll('.shortcut')).forEach((item) => {
    item.addEventListener('click', function() {
        const target = this.dataset.url;
        if (target) {
            window.open(target, '_blank');
        }
    });
});

// AI mode
const aiBtn = document.getElementById('aiBtn');
aiBtn.addEventListener('click', () => {
    const query = document.getElementById('searchInput').value.trim();
    const prompt = query || 'Moshal Tab AI assistant';
    window.location.href = 'https://chat.openai.com/?q=' + encodeURIComponent(prompt);
});

// Optional icons
document.getElementById('voiceBtn').addEventListener('click', () => alert('Voice search is not supported in this demo yet.'));

document.getElementById('cameraBtn').addEventListener('click', () => alert('Image search is not supported in this demo yet.'));
function openAI() {
    window.open("https://ai.studio/apps/9f9ea3b1-3542-4181-8e63-41e7616ef49e");
}function toggleAI() {
    let frame = document.getElementById("aiFrame");
    frame.style.display = frame.style.display === "none" ? "block" : "none";
}function search() {
    let query = document.getElementById("searchInput").value;

    if (query.trim() !== "") {
        window.open("https://www.youtube.com/results?search_query=" + query);
    }
}

function openYouTube() {
    window.open("https://www.youtube.com");
}

function toggleAI() {
    let frame = document.getElementById("aiFrame");

    if (frame.style.display === "none") {
        frame.style.display = "block";
    } else {
        frame.style.display = "none";
    }
}