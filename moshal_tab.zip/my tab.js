function search() {
    let query = document.getElementById("searchInput").value;

    if (query.trim() !== "") {
        window.location.href = "https://www.youtube.com/results?search_query=" + query;
    }
}

// Enter يشتغل
document.getElementById("searchInput").addEventListener("keypress", function(e) {
    if (e.key === "Enter") {
        search();
    }
});